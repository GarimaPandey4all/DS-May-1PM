#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arr[10], i, n, search, first, last, mid;

    printf("enter number of elements:");
    scanf("%d", &n);

    printf("Enter Elements:\n");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }

    printf("Enter value to be search:");
    scanf("%d", &search);

    first = 0;
    last = n - 1;

    mid = (first + last)/2;

    while(first <= last)
    {
        if(arr[mid] < search)
        {
            first = mid + 1;
        }
        else if(arr[mid] == search)
        {
            printf("Value is found at location %d", (mid + 1));
            exit(0);
        }
        else {
            last = mid - 1;
        }

        mid = (first + last)/2;

    }


    return 0;
}
