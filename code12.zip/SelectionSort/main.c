#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arr[10], i, n, j, temp, min;

    printf("enter number of elements:");
    scanf("%d", &n);

    printf("Enter Elements:\n");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }

    printf("Values are:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", arr[i]);
    }

    // 10 3 1 5 6
    // 1, 3, 10, 5, 6
    for(i = 0; i < n - 1; i++)
    {
        min = i; // 0
        for(j = i + 1; j < n; j++)
        {
            if(arr[j] < arr[min])
            min = j; // 1, 2
        }

        //swapping
        temp = arr[i];
        arr[i] = arr[min];
        arr[min] = temp;
    }

    printf("\nSorted Array:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", arr[i]);
    }


    return 0;
}
