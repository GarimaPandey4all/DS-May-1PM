#include <stdio.h>
#include <stdlib.h>
#define SIZE 10

struct Dataset {
    int data;
    int key;
};

struct Dataset *hashArray[SIZE];
struct Dataset *dummyItem;
struct Dataset *item;

int hashFunction(int key)
{
    return key % SIZE; // return hashIndex
}

void insert(int key, int data)
{
    struct Dataset *item;

    item = (struct Dataset *)malloc(sizeof(struct Dataset));

    item->data = data;
    item->key  = key;

    int hashIndex = hashFunction(key);

    //Linear Probing
    while(hashArray[hashIndex] != NULL && hashArray[hashIndex]->key != -1) // data = -1, key = -1
    {
        ++hashIndex;

        hashIndex %= SIZE; // find correct hashIndex
    }

    hashArray[hashIndex] = item;
}

struct Dataset *search(int key)
{
    int hashIndex;

    hashIndex = hashFunction(key);

    while(hashArray[hashIndex] != NULL)
    {
        if(hashArray[hashIndex]->key == key)
        {
            return hashArray[hashIndex];
        }

        ++hashIndex;
        hashIndex %= SIZE;
    }

    return NULL;
};

struct Dataset *delete(struct Dataset *item)
{
    struct Dataset *temp;
    int key;

    key = item->key;

    int hashIndex = hashFunction(key);

    while(hashArray[hashIndex] != NULL)
    {
        if(hashArray[hashIndex]->key == key)
        {
            temp = hashArray[hashIndex];
            hashArray[hashIndex] = dummyItem; // data =  -1, key = -1
            return temp;
        }

        ++hashIndex;
        hashIndex %= SIZE;
    }

    return NULL;
};

void display()
{
    int i;

    for(i = 0; i < SIZE; i++)
    {
        if(hashArray[i] != NULL)
        {
            printf("(%d, %d)", hashArray[i]->key, hashArray[i]->data);
        }
        else {
            printf("__");
        }
    }
}


int main()
{
    dummyItem = (struct Dataset *)malloc(sizeof(struct Dataset));

    dummyItem->data = -1;
    dummyItem->key = -1;

    insert(1, 20);
    insert(3, 40);
    insert(5, 50);
    insert(7, 60);
    insert(6, 56);
    insert(27, 35);

    display();

    item = search(3);

    if(item != NULL)
    {
        printf("\nElement is found: %d\n", item->data);
    }
    else {
        printf("\nElement is not Found\n");
    }

    delete(item);

    display();


    return 0;
}
