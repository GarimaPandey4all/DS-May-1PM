#include <stdio.h>
#include <stdlib.h>

struct node {
    int info;
    struct node *left;
    struct node *right;
};

struct node *createNode(int value)
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    n->info = value;
    n->left = NULL;
    n->right = NULL;

    return n;
};

void inOrder(struct node *root)
{
    if(root != NULL)
    {
        inOrder(root->left);
        printf("%d  ", root->info);
        inOrder(root->right);
    }
}

void preOrder(struct node *root)
{
    if(root != NULL)
    {
        printf("%d  ", root->info);
        preOrder(root->left);
        preOrder(root->right);
    }
}

void postOrder(struct node *root)
{
    if(root != NULL)
    {
        postOrder(root->left);
        postOrder(root->right);
        printf("%d  ", root->info);
    }
}


struct node *insertLeft(struct node *root, int value)
{
    root->left = createNode(value);
    return root->left;
};


struct node *insertRight(struct node *root, int value)
{
    root->right = createNode(value);
    return root->right;
};

int main()
{
    struct node *root = createNode(1);

    insertLeft(root, 12);
    insertRight(root, 9);

    insertLeft(root->left, 5);
    insertRight(root->left, 6);

    insertLeft(root->right, 3);
    insertRight(root->right, 7);

    printf("Inorder Traversal:\n");
    inOrder(root);


    printf("\nPreorder Traversal:\n");
    preOrder(root);


    printf("\nPostorder Traversal:\n");
    postOrder(root);

    return 0;
}
