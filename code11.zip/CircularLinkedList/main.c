#include <stdio.h>
#include <stdlib.h>

struct node {
    int info;
    struct node *link;
};

struct node *last = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return n;
};

//Insert at empty list
void insertAtEmpty()
{
    struct node *temp;

    if(last == NULL)
    {
        temp = createNode();

        printf("Enter any number:");
        scanf("%d", &temp->info);

        last = temp;
        last->link = last;
    }
    else {
        printf("List is not Empty");
    }
}

void insertAtStart()
{
    struct node *temp;

    if(last == NULL)
    {
        printf("List is Empty");
    }
    else {
        temp = createNode();

        printf("Enter any number:");
        scanf("%d", &temp->info);

        temp->link = last->link;
        last->link = temp;
    }
}

void insertAtEnd()
{
    struct node *temp;

    if(last == NULL)
    {
        printf("List is Empty");
    }
    else {
        temp = createNode();

        printf("Enter any number:");
        scanf("%d", &temp->info);

        temp->link = last->link;
        last->link = temp;

        last = temp;
    }
}

int insertAfterNode()
{
    struct node *temp, *ptr;
    int search;

    if(last == NULL)
    {
        printf("List is Empty");
        return 0; // 0 - failure case
    }

    printf("Enter any value to be search:");
    scanf("%d", &search);

    ptr = last->link;

    do {
        if(ptr->info == search)
        {
            temp = createNode();

            printf("Enter any number:");
            scanf("%d", &temp->info);

            temp->link = ptr->link;
            ptr->link = temp;

            if(ptr == last)
            {
                last = temp;
            }

            return 1; // 1 - success case
        }
        ptr = ptr->link;
    }while(ptr != last->link);

    printf("%d is not found in a list", search);
    return 0;
}

void viewList()
{
    struct node *t;

    if(last == NULL)
    {
        printf("List is empty");
    }
    else {
        t = last->link;

        do{
            printf("%d  ", t->info);
            t = t->link;
        }while(t != last->link);
    }
}

int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Insert at Empty\n");
        printf("2. Insert at Start\n");
        printf("3. Insert at End\n");
        printf("4. Insert After Node\n");
        printf("5. View List\n");
        printf("6. Exit\n");

        printf("\n\n Enter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            insertAtEmpty();
            break;

        case 2:
            insertAtStart();
            break;

        case 3:
            insertAtEnd();
            break;

        case 4:
            insertAfterNode();
            break;

        case 5:
            viewList();
            break;

        case 6:
            exit(0);

        default:
            printf("Invalid Choice");
        }
    }


    return 0;
}
