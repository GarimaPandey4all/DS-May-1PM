#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arr[10], i, j, n, temp;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter values in an array:");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }

    printf("Values in an Array:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }

    //logic of insertion sort

//    10, 3, 7, 5, 2
//    3, 10, 7, 5, 2

    for(i = 1; i < n; i++)
    {
        temp = arr[i]; // 3
        j = i - 1;

        while(j >= 0 && arr[j] > temp) // 10 > 3
        {
            arr[j + 1] = arr[j];
            j = j - 1;
        }

        arr[j + 1] = temp; // arr[0] = 3
    }

    printf("\nSorted Array is:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }

    return 0;
}
