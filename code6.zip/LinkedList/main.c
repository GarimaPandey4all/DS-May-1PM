#include <stdio.h>
#include <stdlib.h>

struct node {
    int info;
    struct node *link;
};

struct node *START = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return (n);
};

void insertNode()
{
    struct node *temp, *t;

    temp = createNode(); // n

    printf("Enter any number:");
    scanf("%d", &temp->info);

    temp->link = NULL;

    if(START == NULL)
    {
        START = temp;
    }
    else {
        t = START;

        while(t->link != NULL)
        {
            t = t->link;
        }

        t->link = temp;
    }
}

void deleteNode()
{
    struct node *t;

    if(START == NULL)
    {
        printf("List is Empty");
    }
    else
    {
        t = START;

        START = START->link;

        free(t);
    }
}

void searchList()
{
    struct node *t;
    int search;

    if(START != NULL)
    {
        t = START;

        printf("Enter any value to be search:");
        scanf("%d", &search);

        while(t != NULL)
        {
            if(t->info == search)
            {
                printf("Search value is found: %d", search);
            }
            t = t->link;
        }
    }
    else {
        printf("List is empty. Invalid Search");
    }
}

void viewList()
{
    struct node *t;

    if(START == NULL)
    {
        printf("List is Empty");
    }
    else {
        t = START;

        while(t != NULL)
        {
            printf("%d  ", t->info);
            t = t->link;
        }
    }
}

int main()
{
    //Menu Driven Program

    int choice;

    while(1)
    {
        printf("\n\nPress 1. Insert\n");
        printf("Press 2. Delete\n");
        printf("Press 3. Search\n");
        printf("Press 4. View List\n");
        printf("Press 5. Exit\n");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            insertNode();
            break;

        case 2:
            deleteNode();
            break;

        case 3:
            searchList();
            break;

        case 4:
            viewList();
            break;

        case 5:
            exit(0); // exit the program

        default:
            printf("Invalid Choice");
        }
    }

    return 0;
}
