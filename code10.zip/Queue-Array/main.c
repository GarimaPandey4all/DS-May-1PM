#include <stdio.h>
#include <stdlib.h>
#define SIZE 5

int item[SIZE], front = -1, rear = -1;

//Insert into a queue
void enqueue()
{
    int value;

    if(rear == SIZE - 1)
    {
        printf("Queue is full");
    }
    else {
        printf("Enter any value:");
        scanf("%d", &value);

        if(front == -1)
        {
            front = 0;
        }

        rear++;
        item[rear] = value;
    }
}

//Delete from the queue
void dequeue()
{
    if(front == -1)
    {
        printf("Queue is empty");
    }
    else {
        printf("Deleted value is: %d", item[front]);
        front++;

        if(front > rear)
        {
            front = rear - 1;
        }
    }
}

void display()
{
    if(front == -1)
    {
        printf("Queue is empty");
    }
    else {
        int i;
        printf("Elements in queue are:\n");
        for(i = front; i <= rear; i++)
        {
            printf("%d  ", item[i]);
        }
    }
}

int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Enqueue()\n");
        printf("2. Dequeue()\n");
        printf("3. Display()\n");
        printf("4. Exit\n");

        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            enqueue();
            break;

        case 2:
            dequeue();
            break;

        case 3:
            display();
            break;

        case 4:
            exit(0);

        default:
            printf("Invalid Choice");
        }
    }

    return 0;
}
