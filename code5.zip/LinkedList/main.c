#include <stdio.h>
#include <stdlib.h>

struct node {
    int info;
    struct node *link;
};

struct node *START = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return (n);
};

void insertNode()
{
    struct node *temp, *t;

    temp = createNode(); // n

    printf("Enter any number:");
    scanf("%d", &temp->info);

}


int main()
{


    return 0;
}
