#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    int numbers[5];

    //traditional way of initialization
    //int lists[5] = {2, 4, 1, 5, 6};

    //Compile time Initialization
    int lists[] = {1, 2, 4, 4, 5};

    //int lists[]; // error

//    printf("First value of array is: %d\n\n", lists[3]);
//
//    printf("Values in Array are:\n");
//    for(i = 0; i < 5; i++)
//    {
//        printf("%d\t", lists[i]);
//    }

    printf("Enter values in an Array:\n");
    for(i = 0; i < 5; i++)
    {
        scanf("%d", &numbers[i]);
    }

    printf("Values in an Array are:\n");
    for(i = 0; i < 5; i++)
    {
        printf("%d\t", numbers[i]);
    }

    return 0;
}
