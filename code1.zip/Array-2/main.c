#include <stdio.h>
#include <stdlib.h>
#define MONTHS 12 // macros - create your own pre-processor directive

int main()
{
    int days[MONTHS] = {31, 29, 31, 30, 31, 30, 31, 30, 31, 30, 30, 31};
    int i;

    for(i = 0; i < MONTHS; i++)
    {
        printf("%d month has %d days.\n", i + 1, days[i]);
    }

    return 0;
}
